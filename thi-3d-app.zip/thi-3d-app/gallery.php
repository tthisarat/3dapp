<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/custom.css">

    <title>Bed Museum Gallery</title>

    <!-- X3DOM resources -->
    <link rel='stylesheet' type='text/css' href='http://www.x3dom.org/x3dom/release/x3dom.css'></link>

  </head>
  <body>

    <!-- HEADER INCLUDE -->
    <?php include 'includes/header.html'; ?>

    <div class="container-fluid">
      <h1>Virtual Gallery</h1>
      <p style="font-size: 20px;">Browse the gallery for ancient beds in 3d.</p>
      <p><strong style="color:red;">Developer Notes:</strong><br />
            Blender cannot export image textures due to bug: <a href="https://developer.blender.org/T66534" target="_blank">https://developer.blender.org/T66534</a></p>
      <div class="row">
          <div class="col-xs-12 col-sm-8" >
            <div class="gallery-item">
              <p>Please select an option first using the buttons provided.</p>
             
            </div>
            <div class="gallery-item bed-image-1">
              <img src="assets/images/ancient-bed.jpg" alt="Ancient bed" />
            </div>

            <!--  bed 1 ======================= -->
            <div class="gallery-item x3dom-item-1">

                <div class="row">
                <div class="col-xs-12 col-sm-8">

                    <?php include 'includes/bed-1.html'; ?>

                    <div class="bed-colours">
                    <button onclick="changeColour('bed-1-colour','#efebe0')" style="background-color:#efebe0;"></button>
                    <button onclick="changeColour('bed-1-colour','#ff9900')" style="background-color:#ff9900;"></button>
                    <button onclick="changeColour('bed-1-colour','#000066')" style="background-color:#000066;"></button>
                    <button onclick="changeColour('bed-1-colour','#003333')" style="background-color:#003333;"></button>
                    <button onclick="changeColour('bed-1-colour','#330033')" style="background-color:#330033;"></button>
                    </div>

                    <div class="more-controls">
                    <button onclick="toggleWireframe('bed-1',true);">Wireframe ON</button>
                    <button onclick="toggleWireframe('bed-1',false);">Wireframe OFF</button><br />
                    <button onclick="changeCamera('bed-1-front-camera');">Front Camera</button>
                    <button onclick="changeCamera('bed-1-side-camera');">Side Camera</button>
                    <button onclick="changeCamera('bed-1-back-camera');">Back Camera</button><br />
                    <!-- <button onclick="$('#bed-1-brightlight').show();">Bright Light ON</button>
                    <button onclick="$('#bed-1-brightlight').hide();">Bright Light OFF</button> -->
                    </div>

                    <div class="bed-textures">
                    <button onclick="changeTexture('bed-1-material','assets/blender_beds/textures/wood-1.jpg')"><img src="assets/blender_beds/textures/wood-1.jpg" /></button>
                    <button onclick="changeTexture('bed-1-material','assets/blender_beds/textures/wood-2.jpg')"><img src="assets/blender_beds/textures/wood-2.jpg" /></button>
                    </div>
                    </div> 
                    <div class="col-xs-12 col-sm-4">
                    <div id="bed-1-description">
                        <button onClick="loadDescription('bed-1', 'bed-1-description'); this.remove();">Load Description</button>
                    </div>
                    </div>
                </div>
                
            </div>

            <!--  bed 2 ======================= -->
            <div class="gallery-item x3dom-item-2">
              
            <div class="row">
                <div class="col-xs-12 col-sm-8">

                    <?php include 'includes/bed-2.html'; ?>

                    <div class="bed-colours">
                    <button onclick="changeColour('bed-2-colour','#efebe0')" style="background-color:#efebe0;"></button>
                    <button onclick="changeColour('bed-2-colour','#ff9900')" style="background-color:#ff9900;"></button>
                    <button onclick="changeColour('bed-2-colour','#000066')" style="background-color:#000066;"></button>
                    <button onclick="changeColour('bed-2-colour','#003333')" style="background-color:#003333;"></button>
                    <button onclick="changeColour('bed-2-colour','#330033')" style="background-color:#330033;"></button>
                    </div>

                    <div class="more-controls">
                    <button onclick="toggleWireframe('bed-2',true);">Wireframe ON</button>
                    <button onclick="toggleWireframe('bed-2',false);">Wireframe OFF</button><br />
                    <button onclick="changeCamera('bed-2-front-camera');">Front Camera</button>
                    <button onclick="changeCamera('bed-2-side-camera');">Side Camera</button>
                    <button onclick="changeCamera('bed-2-back-camera');">Back Camera</button><br />
                    <!-- <button onclick="$('#bed-1-brightlight').show();">Bright Light ON</button>
                    <button onclick="$('#bed-1-brightlight').hide();">Bright Light OFF</button> -->
                    </div>

                    <div class="bed-textures">
                    <button onclick="changeTexture('bed-2-material','assets/blender_beds/textures/wood-1.jpg')"><img src="assets/blender_beds/textures/wood-1.jpg" /></button>
                    <button onclick="changeTexture('bed-2-material','assets/blender_beds/textures/wood-2.jpg')"><img src="assets/blender_beds/textures/wood-2.jpg" /></button>
                    </div>
                    </div> 
                    <div class="col-xs-12 col-sm-4">
                    <div id="bed-2-description">
                        <button onClick="loadDescription('bed-2', 'bed-2-description'); this.remove();">Load Description</button>
                    </div>
                    </div>
                </div>

            </div>

            <!--  bed 3 ======================= -->
            <div class="gallery-item x3dom-item-3">
              
            <div class="row">
                <div class="col-xs-12 col-sm-8">

                    <?php include 'includes/bed-3.html'; ?>

                    <div class="bed-colours">
                    <button onclick="changeColour('bed-3-colour','#efebe0')" style="background-color:#efebe0;"></button>
                    <button onclick="changeColour('bed-3-colour','#ff9900')" style="background-color:#ff9900;"></button>
                    <button onclick="changeColour('bed-3-colour','#000066')" style="background-color:#000066;"></button>
                    <button onclick="changeColour('bed-3-colour','#003333')" style="background-color:#003333;"></button>
                    <button onclick="changeColour('bed-3-colour','#330033')" style="background-color:#330033;"></button>
                    </div>

                    <div class="more-controls">
                    <button onclick="toggleWireframe('bed-3',true);">Wireframe ON</button>
                    <button onclick="toggleWireframe('bed-3',false);">Wireframe OFF</button><br />
                    <button onclick="changeCamera('bed-3-front-camera');">Front Camera</button>
                    <button onclick="changeCamera('bed-3-side-camera');">Side Camera</button>
                    <button onclick="changeCamera('bed-3-back-camera');">Back Camera</button><br />
                    <!-- <button onclick="$('#bed-1-brightlight').show();">Bright Light ON</button>
                    <button onclick="$('#bed-1-brightlight').hide();">Bright Light OFF</button> -->
                    </div>

                    <div class="bed-textures">
                    <button onclick="changeTexture('bed-3-material','assets/blender_beds/textures/wood-1.jpg')"><img src="assets/blender_beds/textures/wood-1.jpg" /></button>
                    <button onclick="changeTexture('bed-3-material','assets/blender_beds/textures/wood-2.jpg')"><img src="assets/blender_beds/textures/wood-2.jpg" /></button>
                    </div>
                    </div> 
                    <div class="col-xs-12 col-sm-4">
                    <div id="bed-3-description">
                        <button onClick="loadDescription('bed-3', 'bed-3-description'); this.remove();">Load Description</button>
                    </div>
                    </div>
                </div>

            </div>

            <!--  bed 4 ======================= -->
            <div class="gallery-item x3dom-item-4">
             
            <div class="row">
                <div class="col-xs-12 col-sm-8">

                    <?php include 'includes/bed-4.html'; ?>

                    <div class="bed-colours">
                    <button onclick="changeColour('bed-4-colour','#efebe0')" style="background-color:#efebe0;"></button>
                    <button onclick="changeColour('bed-4-colour','#ff9900')" style="background-color:#ff9900;"></button>
                    <button onclick="changeColour('bed-4-colour','#000066')" style="background-color:#000066;"></button>
                    <button onclick="changeColour('bed-4-colour','#003333')" style="background-color:#003333;"></button>
                    <button onclick="changeColour('bed-4-colour','#330033')" style="background-color:#330033;"></button>
                    </div>

                    <div class="more-controls">
                    <button onclick="toggleWireframe('bed-4',true);">Wireframe ON</button>
                    <button onclick="toggleWireframe('bed-4',false);">Wireframe OFF</button><br />
                    <button onclick="changeCamera('bed-4-front-camera');">Front Camera</button>
                    <button onclick="changeCamera('bed-4-side-camera');">Side Camera</button>
                    <button onclick="changeCamera('bed-4-back-camera');">Back Camera</button><br />
                    <!-- <button onclick="$('#bed-1-brightlight').show();">Bright Light ON</button>
                    <button onclick="$('#bed-1-brightlight').hide();">Bright Light OFF</button> -->
                    </div>

                    <div class="bed-textures">
                    <button onclick="changeTexture('bed-4-material','assets/blender_beds/textures/wood-1.jpg')"><img src="assets/blender_beds/textures/wood-1.jpg" /></button>
                    <button onclick="changeTexture('bed-4-material','assets/blender_beds/textures/wood-2.jpg')"><img src="assets/blender_beds/textures/wood-2.jpg" /></button>
                    </div>
                    </div> 
                    <div class="col-xs-12 col-sm-4">
                    <div id="bed-4-description">
                        <button onClick="loadDescription('bed-4', 'bed-4-description'); this.remove();">Load Description</button>
                    </div>
                    </div>
                </div>

            </div>

            <div class="gallery-item audio-item" style="display:block;">
              <p>Listen to the introduction:</p>
              <div id="soundUrl">
                <audio width="100%" controls="">
                  <source src="assets/audio/introduction.mp3" type="audio/mpeg">
                  </audio> 
              </div>
            </div>
         
          </div>
          <div class="col-xs-12 col-sm-4">
            <div class="options">
              <button onclick="showItem('.audio-item')">View Introduction</button>
              <button onclick="showItem('.bed-image-1')">View Bed Image</button>
              <button onclick="showItem('.x3dom-item-1')">View Roman Bed</button>
              <button onclick="showItem('.x3dom-item-2')">View Medieval Bed</button>
              <button onclick="showItem('.x3dom-item-3')">View Ancient Egyptian</button>
              <button onclick="showItem('.x3dom-item-4')">View Ancient Greek Bed</button>
            </div>
          </div>

      </div>
     
    </div>
    
    <!-- FOODTER INCLUDE -->
    <?php include 'includes/footer.html'; ?>


    <!--X3DOM-->
    <script type='text/javascript' src='http://www.x3dom.org/x3dom/release/x3dom.js'></script>

    <!-- jquery cdn -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- My custom functions -->
    <script src="js/my-app.js"></script>
  </body>
</html>

