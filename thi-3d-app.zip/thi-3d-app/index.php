<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/custom.css">

    <title>Bed Museum Homepage</title>

    <!-- X3DOM resources -->
    <link rel='stylesheet' type='text/css' href='http://www.x3dom.org/x3dom/release/x3dom.css'></link>

  </head>
  <body>
   
    <!-- HEADER INCLUDE -->
    <?php include 'includes/header.html'; ?>


    <div class="container-fluid">
      <h1>Welcome to the museum of beds</h1>
      <p style="font-size: 20px;">Please browse the difference ancient bed models in 3d in our <a href="gallery.php">gallery!</a></p>
      <div class="row">
          <div class="col-xs-12 col-sm-4" style="background-color:lavenderblush;">
            <div class="image">
              <img src="assets/images/ancient-bed.jpg" alt="Ancient bed" />
            </div>
            <p>This is an acient bed from ancient Rome.</p>
          </div>
          <div class="col-xs-12 col-sm-4" style="background-color:rgb(252, 172, 248);">
            <div class="image">
              <img src="assets/images/ancient-bed-2.jpg" alt="Ancient bed" />
            </div>
            <p>This is an acient bed from the Medieval period.</p>
          </div>

          <div class="col-xs-12 col-sm-4" style="background-color:rgb(214, 125, 207);">
            <div class="image">
              <img src="assets/images/ancient-bed-3.jpg" alt="Ancient bed" />
            </div>
            <p>This is an acient bed from ancient Egyptian times.</p>
          </div>
      </div>
      <br />
      <p><a style="font-size: 18px;" href="gallery.php"><strong>View gallery here</strong></a</p>
    </div>
    
    <!-- FOODTER INCLUDE -->
    <?php include 'includes/footer.html'; ?>


    <!--X3DOM-->
    <script type='text/javascript' src='http://www.x3dom.org/x3dom/release/x3dom.js'></script>

    <!-- jquery cdn -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.js"></script>
  </body>
</html>

