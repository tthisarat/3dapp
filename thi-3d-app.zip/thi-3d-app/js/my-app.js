

function showItem(item) {
    $('.gallery-item').hide();
    $(item).show();
}

function changeTexture(element, image) {
    document.getElementById(element).setAttribute("url", image);
}

function loadDescription(item, element) {

    $.getJSON( "db/models.json", function( data ) {
        var information = [];
        $.each( data[item], function( key, val ) {
            information.push( "<p>" + val + "</p>" );
        });
       
        $('#'+element).append(information);
      });

}

function changeColour(element, colour) {
    document.getElementById(element).setAttribute("diffuseColor", colour);
}

function changeCamera(camera){
    document.getElementById(camera).setAttribute('bind', 'true');
}

function toggleWireframe(element, true_or_false) {
    var e = document.getElementById(element);
	e.runtime.togglePoints(true_or_false);
	e.runtime.togglePoints(true_or_false);
}

function loadX3dom() {
    //after we AJAX the bed we initiate the X3Dom Javascript
    /** Initializes an <x3d> root element that was added after document load. */
   
}

$(function() {

  



});